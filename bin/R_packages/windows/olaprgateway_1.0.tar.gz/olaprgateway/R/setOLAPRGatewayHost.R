setOLAPRGatewayHost <-
function(host) {
   assign("OLAPNetworkHost", host, envir = .GlobalEnv)
   
}
