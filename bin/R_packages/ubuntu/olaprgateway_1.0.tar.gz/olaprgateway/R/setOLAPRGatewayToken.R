setOLAPRGatewayToken <-
function(token) {
   assign("OLAPNetworkToken", token, envir = .GlobalEnv)
   
}
