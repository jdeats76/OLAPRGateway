setOLAPRGatewayPort <-
function(port) {
   assign("OLAPNetworkPort", port, envir = .GlobalEnv)
}
